install.packages("rmarkdown")
install.packages("knitr")
library(knitr)
library(rmarkdown)
library(ggplot2)
library(dplyr)
library(plyr)

###1번###
mpg 
ggplot(mpg, aes(x=cty,y=hwy)) + geom_point()

###2번###
midwest
scat_pop <- midwest %>%
  select(poptotal, popasian) %>%
  filter(poptotal < 500000 & popasian < 10000) 
ggplot(scat_pop, aes(x=poptotal,y=popasian)) +
  geom_point()

###3번####

View(mpg)
sort_suv <- subset(mpg, class=="suv")
sort_cty <- sort_suv %>%
  group_by(manufacturer) %>%
  dplyr::summarise(avg_c = mean(cty)) %>%
  arrange(desc(avg_c))
h <- head(sort_cty,5)

ggplot(h, aes(x=manufacturer,y=avg_c,fill=manufacturer)) +
  geom_bar(stat="identity") + theme(axis.text.x = element_text(angle=45,size=8) )


### 4번###

ggplot(mpg, aes(class)) + geom_bar() + theme(axis.text.x = element_text(angle=45,size=8) )


###5번###
ec <- economics
graph1 <- ggplot(ec, aes(x=date,y=psavert)) + geom_point()
graph1 + geom_line()

###6번###
cls <- mpg %>%
  select(class, cty) %>%
  filter(class=="compact" | class=="subcompact" | class=="suv") %>%
  group_by(class) %>%
  summarise_each(funs(mean), cty)
cls

ggplot(cls,aes(x=class,y=cty,color=class,fill=class)) + geom_bar(stat = "identity")

###7번###
#(1)#
View(dia) <- diamonds
View(dia)
ggplot(dia,aes(cut, fill=cut)) + geom_bar() + 
  theme(axis.text = element_text(angle=45,size=8))

#(2)#
ggplot(dia, aes(x=cut,y=price,fill=cut)) + geom_bar(stat = "identity")

#(3)#
View(diamonds)
dia <- diamonds
dia_f <- dia %>%
  filter(cut == 'Fair') %>%
  group_by(color) %>%
  dplyr::summarise(avg = mean(price))

ggplot(dia_f, aes(x=color,y=avg,fill=color)) + geom_bar(stat = "identity")

dia_g <- dia %>%
  filter(cut == 'Good') %>%
  group_by(color) %>%
  dplyr::summarise(avg = mean(price))
dia_g
ggplot(dia_g, aes(x=color,y=avg,fill=color)) + geom_bar(stat = "identity")

dia_v <- dia %>%
  filter(cut == 'Very Good') %>%
  group_by(color) %>%
  dplyr::summarise(avg = mean(price))

ggplot(dia_v, aes(x=color,y=avg,fill=color)) + geom_bar(stat = "identity")

dia_p <- dia %>%
  filter(cut == 'Premium') %>%
  group_by(color) %>%
  dplyr::summarise(avg = mean(price))

ggplot(dia_p, aes(x=color,y=avg,fill=color)) + geom_bar(stat = "identity")

dia_i <- dia %>%
  filter(cut == 'Ideal') %>%
  group_by(color) %>%
  dplyr::summarise(avg = mean(price))

ggplot(dia_i, aes(x=color,y=avg,fill=color)) + geom_bar(stat = "identity")
